import React, { useRef, useState } from 'react';
import { api } from '../api.js';
import { useAppStore } from '../store.js';

function formatError(error) {
  try {
    const parsed = JSON.parse(error?.message || '');
    return typeof parsed === 'string' ? parsed : (parsed.message || parsed.detail || error.message);
  } catch {
    return error?.message || String(error);
  }
}

// 僅更新 2D 羽球 CSV；原本的 Rally、3D 與相機參數不會被覆蓋。
export default function Dataset2DFileTools() {
  const matchId = useAppStore(state => state.matchId);
  const refreshAfter2DHistory = useAppStore(state => state.refreshAfter2DHistory);
  const fileRef = useRef(null);
  const [open, setOpen] = useState(false);
  const [files, setFiles] = useState([]);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const totalMb = files.reduce((sum, file) => sum + file.size, 0) / 1024 / 1024;

  const upload = async () => {
    if (matchId == null || !files.length || busy) return;
    setBusy(true);
    setProgress(0);
    setError('');
    setMessage('');
    try {
      const result = await api.replaceDataset2DFiles(matchId, files, setProgress);
      if (useAppStore.getState().matchId === matchId) {
        for (const cameraIndex of result.camera_indices || []) {
          useAppStore.getState().setCameraHasBall2D(cameraIndex, true);
        }
        refreshAfter2DHistory();
      }
      setMessage(`已更新 ${result.replaced_files} 個 CSV、${result.imported_rows} 筆原始 2D。其他檔案及既有 2D 修正不變。`);
      setFiles([]);
      if (fileRef.current) fileRef.current.value = '';
    } catch (reason) {
      setError(formatError(reason));
    } finally {
      setBusy(false);
    }
  };

  if (matchId == null) return null;
  return <>
    <button type="button" onClick={() => { setOpen(true); setError(''); setMessage(''); }}
      className="shrink-0 rounded border border-zinc-700 bg-zinc-900 px-2.5 py-1.5 text-xs text-zinc-200 hover:bg-zinc-800"
      title="更新目前資料集的 2D 標註 CSV，可一次選取多個檔案">
      Update Dataset
    </button>
    {open && <div className="fixed inset-0 z-[120] flex items-center justify-center bg-black/75 p-4">
      <div className="w-full max-w-xl rounded-lg border border-zinc-700 bg-zinc-950 p-5 shadow-2xl text-zinc-200">
        <div className="flex items-center justify-between gap-3">
          <h2 className="font-semibold">Update Dataset｜更新現有資料集</h2>
          <button type="button" disabled={busy} onClick={() => setOpen(false)} className="text-zinc-400 hover:text-white">✕</button>
        </div>
        <div className="mt-5 border-t border-zinc-800 pt-4 font-semibold text-sm">部分重傳／修正 2D CSV</div>
        <p className="mt-3 text-xs leading-6 text-zinc-400">
          目前既有資料集的部分檔案更新支援 2D CSV。一次可選多個 *_ball.csv。依檔名中的 Rally、起訖 Frame 與 View 對應到現有資料集；
          只替換那些 Rally／相機的「原始 2D」，其他 Rally、相機、3D 與影片不受影響。
          既有的人工修正層仍會保留並優先顯示；可以一次重新選取多個修正檔案上傳。
          注意：重傳會整段取代該 Rally／Cam 的原始 CSV；新檔缺少的 Frame 也會被移除。建議先使用 Export Dataset 匯出 2D 備份。
        </p>
        <input ref={fileRef} type="file" accept=".csv,text/csv" multiple disabled={busy}
          onChange={event => { setFiles(Array.from(event.target.files || [])); setError(''); setMessage(''); }}
          className="mt-4 w-full text-xs text-zinc-300 file:mr-3 file:rounded file:border-0 file:bg-indigo-700 file:px-3 file:py-2 file:text-white" />
        <div className="mt-2 text-xs text-zinc-400">已選 {files.length} 個檔案（{totalMb.toFixed(1)} MB），上限 300 個、總計 256 MB。</div>
        {files.length > 0 && <div className="mt-3 max-h-32 overflow-y-auto rounded bg-zinc-900 p-2 text-xs text-zinc-400">
          {files.map((file, index) => <div key={`${index}-${file.name}`}>{file.name}</div>)}
        </div>}
        {busy && <div className="mt-3 text-xs text-indigo-300">上傳中 {progress}%</div>}
        {error && <div className="mt-3 whitespace-pre-wrap rounded bg-red-950/40 p-2 text-xs text-red-300">{error}</div>}
        {message && <div className="mt-3 rounded bg-emerald-950/40 p-2 text-xs text-emerald-300">{message}</div>}
        <div className="mt-4 flex justify-end gap-2">
          <button type="button" disabled={busy} onClick={() => setOpen(false)}
            className="rounded border border-zinc-700 px-3 py-2 text-xs">關閉</button>
          <button type="button" disabled={busy || !files.length} onClick={upload}
            className="rounded bg-indigo-700 px-3 py-2 text-xs font-semibold text-white disabled:opacity-40">
            {busy ? '上傳中…' : `更新選取的 ${files.length} 個檔案`}
          </button>
        </div>
      </div>
    </div>}
  </>;
}
