import React, { useState } from 'react';
import { api } from '../api.js';
import { useAppStore } from '../store.js';

// 分類名稱和「新增資料集」一致；匯出時可只選其中幾類。
const CATEGORIES = [
  ['cameras', '相機參數', '由目前相機設定還原 NPY。'],
  ['rally-data', 'Rally 與擊球標註', '依資料庫重建 RallySeg 和 shot_annotated CSV。'],
  ['ball', '球軌跡', '有效 3D 點重建的 NPY，未保留原始無效點。'],
  ['ball-mask', '球軌跡 Mask', '從有效 3D 位置重建的 Mask，不是原始 Mask 備份。'],
  ['ball-2d', '2D 羽球位置', '輸出修正後的 CSV、人工修正紀錄。'],
  ['human-racket', '人體與球拍重建', '輸出既有處理後 NPZ，不是原始 PTH。'],
];

export default function DatasetExportButton() {
  const matchId = useAppStore(state => state.matchId);
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState(['ball-2d']);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const toggle = category => {
    setSelected(previous => previous.includes(category)
      ? previous.filter(item => item !== category)
      : [...previous, category]);
  };

  const exportSelected = async () => {
    if (busy || matchId == null || selected.length === 0) return;
    setBusy(true);
    setError('');
    try {
      const response = await fetch(api.exportDatasetCategoriesUrl(matchId, selected));
      if (!response.ok) {
        const body = await response.text();
        let message = body;
        try { message = JSON.parse(body)?.detail || body; } catch { /* 後端可能回傳純文字 */ }
        throw new Error(`HTTP ${response.status}：${message}`);
      }
      const content = await response.blob();
      const blobUrl = URL.createObjectURL(content);
      const anchor = document.createElement('a');
      anchor.href = blobUrl;
      anchor.download = `badminton_dataset_${matchId}_selected.zip`;
      document.body.append(anchor);
      anchor.click();
      anchor.remove();
      setTimeout(() => URL.revokeObjectURL(blobUrl), 30000);
      setOpen(false);
    } catch (reason) {
      setError(reason?.message || String(reason));
    } finally {
      setBusy(false);
    }
  };

  if (matchId == null) return null;
  return <>
    <button type="button" onClick={() => { setOpen(true); setError(''); }}
      className="shrink-0 rounded border border-zinc-700 bg-zinc-900 px-2.5 py-1.5 text-xs text-zinc-200 hover:bg-zinc-800">
      Export Dataset
    </button>
    {open && <div className="fixed inset-0 z-[120] flex items-center justify-center bg-black/75 p-4">
      <div className="w-full max-w-2xl rounded-lg border border-zinc-700 bg-zinc-950 p-5 shadow-2xl text-zinc-200">
        <div className="flex justify-between gap-3">
          <div>
            <h2 className="font-semibold">匯出 Dataset</h2>
            <p className="mt-1 text-xs text-zinc-400">勾選要輸出的資料類型，分類與匯入時相同。</p>
          </div>
          <button disabled={busy} type="button" onClick={() => setOpen(false)}>✕</button>
        </div>
        <div className="mt-4 flex gap-2 text-xs">
          <button type="button" disabled={busy} onClick={() => setSelected(CATEGORIES.map(row => row[0]))}
            className="rounded border border-zinc-700 px-2 py-1">全選</button>
          <button type="button" disabled={busy} onClick={() => setSelected([])}
            className="rounded border border-zinc-700 px-2 py-1">清除選取</button>
        </div>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {CATEGORIES.map(([key, title, note]) => <label key={key}
            className="flex cursor-pointer gap-2 rounded border border-zinc-800 bg-zinc-900/60 p-3">
            <input type="checkbox" className="mt-1" checked={selected.includes(key)}
              disabled={busy} onChange={() => toggle(key)} />
            <span className="min-w-0">
              <span className="block text-sm text-zinc-200">{title}</span>
              <span className="block mt-1 text-xs leading-5 text-zinc-400">{note}</span>
            </span>
          </label>)}
        </div>
        <p className="mt-3 text-xs leading-5 text-amber-300">
          提醒：匯入時沒有保留的原始 Mask／無效 3D 內容無法復原；匯出 ZIP 附有資料來源說明。這不是原始檔案的完整備份。
        </p>
        {error && <p className="mt-3 whitespace-pre-wrap rounded bg-red-950/50 p-2 text-xs text-red-300">{error}</p>}
        <div className="mt-4 flex justify-end gap-2">
          <button type="button" disabled={busy} onClick={() => setOpen(false)}
            className="rounded border border-zinc-700 px-3 py-2 text-xs">取消</button>
          <button type="button" disabled={busy || selected.length === 0} onClick={exportSelected}
            className="rounded bg-indigo-700 px-3 py-2 text-xs font-semibold text-white disabled:opacity-40">
            {busy ? '正在打包…' : `匯出所選 ${selected.length} 類（ZIP）`}
          </button>
        </div>
      </div>
    </div>}
  </>;
}
