"""既有資料集的部分 2D CSV 重傳。

同一次可上傳多個 Rally／相機檔案，只替換對應的原始 2D 資料。
所有檔案先通過檢查才動資料庫；既有修正層另行保留。
"""

import tempfile
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy import insert
from sqlalchemy.orm import Session

from .dataset_upload import BALL_2D_FILENAME_PATTERN, read_ball_2d_record
from .db import get_db
from .models import BallPosition2D, Match, Rally
from .repair_geometry import cameras_by_index_for_match

router = APIRouter()
MAX_FILES = 300
MAX_FILE_BYTES = 24 * 1024 * 1024
MAX_TOTAL_BYTES = 256 * 1024 * 1024


async def parse_files(files, rallies, cameras):
    """檔名決定 Rally/視角；檢查全部通過後才回傳待匯入列。"""
    lookup = {(int(r.rally_index), int(r.start_frame), int(r.end_frame)): r for r in rallies}
    seen = set()
    parsed = []
    total_bytes = 0
    with tempfile.TemporaryDirectory(prefix='badminton-2d-reupload-') as folder:
        base = Path(folder)
        for index, upload in enumerate(files):
            name = Path(upload.filename or '').name
            parts = BALL_2D_FILENAME_PATTERN.fullmatch(name)
            if parts is None:
                raise HTTPException(400, detail=f'{name}：檔名須為 matchN_R_START_END_viewC_ball.csv')
            meta = {key: int(value) for key, value in parts.groupdict().items()}
            key = (meta['rally'], meta['start'], meta['end'])
            if key not in lookup:
                raise HTTPException(400, detail=f'{name}：找不到相同編號與影格範圍的 Rally')
            if meta['camera'] not in cameras:
                raise HTTPException(400, detail=f'{name}：Cam {meta["camera"]} 不在這份資料集')
            unique = (lookup[key].id, meta['camera'])
            if unique in seen:
                raise HTTPException(400, detail=f'{name}：同一批檔案不能重複指定相同 Rally/相機')
            seen.add(unique)

            path = base / f'{index}.csv'
            size = 0
            try:
                with path.open('wb') as output:
                    while chunk := await upload.read(1024 * 1024):
                        size += len(chunk)
                        total_bytes += len(chunk)
                        if size > MAX_FILE_BYTES or total_bytes > MAX_TOTAL_BYTES:
                            raise HTTPException(413, detail='單檔最多 24 MB，單次上傳最多 256 MB')
                        output.write(chunk)
                if size == 0:
                    raise HTTPException(400, detail=f'{name} 是空檔案')
            finally:
                await upload.close()

            record = {
                'original_name': name,
                'relative_path': f'rally{meta["rally"]}/view{meta["camera"]}/v3/{name}',
                'stored_path': path.name,
            }
            metadata, data, errors = read_ball_2d_record(base, record)
            if errors or data is None:
                raise HTTPException(400, detail='；'.join(errors) or f'{name} 解析失敗')
            rows = [{
                'camera_index': meta['camera'],
                'frame': meta['start'] + int(row.frame),
                'visibility': int(row.visibility),
                'x': float(row.x), 'y': float(row.y),
            } for row in data.itertuples(index=False)]
            parsed.append((meta, rows, name))
    return parsed


@router.post('/matches/{match_id}/traj2d/replace-files')
async def replace_dataset_2d_files(
    match_id: int,
    files: list[UploadFile] = File(...),
    db: Session = Depends(get_db),
):
    """只覆蓋指定的 Rally×Cam 原始標註，其餘 Rally/視角及人工修正不變。"""
    if not files or len(files) > MAX_FILES:
        raise HTTPException(400, detail=f'一次請選擇 1～{MAX_FILES} 個 2D CSV')

    match = db.query(Match).filter(Match.id == match_id).with_for_update().first()
    if match is None:
        raise HTTPException(404, detail='找不到資料集')
    rallies = db.query(Rally).filter(Rally.match_id == match_id).all()
    cameras = cameras_by_index_for_match(match)
    parsed = await parse_files(files, rallies, cameras)

    try:
        total_rows = 0
        new_files = {}
        # 同一交易完成全部檔案替換，遇到錯誤時全數復原。
        for metadata, rows, name in parsed:
            old_rows = db.query(BallPosition2D.id).filter(
                BallPosition2D.match_id == match_id,
                BallPosition2D.camera_index == metadata['camera'],
                BallPosition2D.frame >= metadata['start'],
                BallPosition2D.frame < metadata['end'],
            ).first()
            if old_rows is None:
                index = metadata['camera']
                new_files[index] = new_files.get(index, 0) + 1
            db.query(BallPosition2D).filter(
                BallPosition2D.match_id == match_id,
                BallPosition2D.camera_index == metadata['camera'],
                BallPosition2D.frame >= metadata['start'],
                BallPosition2D.frame < metadata['end'],
            ).delete(synchronize_session=False)
            for start in range(0, len(rows), 3000):
                values = [{**row, 'match_id': match_id} for row in rows[start:start + 3000]]
                db.execute(insert(BallPosition2D), values)
            total_rows += len(rows)
        # 新補進來的視角也要讓影片面板知道，否則畫面仍把它當成沒有 2D。
        camera_list = [dict(item) if isinstance(item, dict) else item
                       for item in (match.cameras or [])]
        for item in camera_list:
            if not isinstance(item, dict):
                continue
            index = item.get('index')
            try:
                index = int(index)
            except (ValueError, TypeError):
                continue
            if any(metadata['camera'] == index for metadata, _, _ in parsed):
                item['has_ball_2d'] = True
                item['ball_2d_file_count'] = int(item.get('ball_2d_file_count') or 0) + new_files.get(index, 0)
        match.cameras = camera_list
        db.commit()
        return {
            'ok': True, 'replaced_files': len(parsed), 'imported_rows': total_rows,
            'camera_indices': sorted({meta['camera'] for meta, _, _ in parsed}),
            'files': [name for _, _, name in parsed],
            'corrections_preserved': True,
        }
    except Exception:
        db.rollback()
        raise
