"""依照匯入類別選擇要匯出的資料。

資料庫不保留原始 NPY 裡無效影格的內容；球軌跡和 Mask 由已匯入的
有效 3D 點重建，不能拿這份 ZIP 當作原始輸入檔的逐位元備份。
"""

import csv
import io
import json
import tempfile
import zipfile
from pathlib import Path

import numpy as np
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.background import BackgroundTasks
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from .ball2d_corrections import export_corrected_ball_2d
from .dataset_upload import CATEGORY_NAMES
from .db import get_db
from .models import BallTraj, Hit, Match, MatchPlayer, Player, Rally
from .reconstruction_assets import match_asset_dir, read_match_asset_manifest

router = APIRouter()


def _csv(columns, rows):
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(columns)
    writer.writerows(rows)
    return output.getvalue()


def _npy(value):
    output = io.BytesIO()
    np.save(output, np.asarray(value), allow_pickle=False)
    return output.getvalue()


def _export_cameras(archive, match):
    count = 0
    for camera in match.cameras or []:
        if not isinstance(camera, dict):
            continue
        projection = camera.get('projection') or {}
        index = int(camera['index'])
        for kind in ('intrinsic', 'extrinsic'):
            value = projection.get(kind)
            if value is not None:
                archive.writestr(f'cameras/Cam_{index}_{kind}.npy', _npy(value))
                count += 1
    archive.writestr('cameras/camera_settings.json', json.dumps(
        {'fps': match.fps, 'cameras': match.cameras}, ensure_ascii=False, indent=2))
    return count + 1


def _export_rallies(archive, db, match_id, rallies):
    roster = db.query(MatchPlayer, Player).join(
        Player, MatchPlayer.player_id == Player.id,
    ).filter(MatchPlayer.match_id == match_id).all()
    names = {}
    for member, player in roster:
        names.setdefault(int(member.team), []).append((int(member.seat), member.source_name or player.name))
    teams = {team: '/'.join(name for _, name in sorted(members))
             for team, members in names.items()}
    hits = db.query(Hit).filter(Hit.match_id == match_id).order_by(Hit.hit_frame).all()
    shots_by_rally = {}
    for hit in hits:
        shots_by_rally.setdefault(int(hit.rally_id), []).append(hit)
    by_game = {}
    for rally in rallies:
        by_game.setdefault(int(rally.game_index), []).append(rally)
    count = 0
    for game, group in sorted(by_game.items()):
        prefix = f'rally-data/Set{game}'
        archive.writestr(f'{prefix}/RallySeg.csv', _csv(
            ['Score', 'Start', 'End', 'UpCourt', 'DownCourt'],
            [[r.score_label, r.start_frame, r.end_frame,
              teams.get(int(r.up_team), ''), teams.get(1 - int(r.up_team), '')]
             for r in group],
        ))
        shot_rows = []
        for rally in group:
            for hit in shots_by_rally.get(int(rally.id), []):
                shot_rows.append([
                    rally.score_label, hit.ball_round, hit.player,
                    hit.hit_frame, hit.new_hit_frame if hit.new_hit_frame is not None else '',
                    hit.shot_type, hit.hand, hit.note,
                ])
        archive.writestr(f'{prefix}/shot_annotated.csv', _csv(
            ['Rally', 'Ball Round', 'player', 'Hit Frame', 'New Hit Frame',
             'Shot Type', 'Hand', 'Note'], shot_rows,
        ))
        count += 2
    return count


def _export_ball_arrays(archive, db, match_id, rallies, selected):
    # 原始 mask=0 的座標未存入資料庫，NaN 代表未知，不可偽造為實際 3D。
    count = 0
    for rally in rallies:
        start, end = int(rally.start_frame), int(rally.end_frame)
        if end <= start:
            continue
        points = db.query(BallTraj).filter(
            BallTraj.match_id == match_id,
            BallTraj.frame >= start,
            BallTraj.frame < end,
        ).all()
        if not points:
            continue
        ball = np.full((end - start, 3), np.nan, dtype=np.float64)
        mask = np.zeros(end - start, dtype=np.uint8)
        for point in points:
            index = int(point.frame) - start
            mask[index] = 1
            ball[index] = (float(point.x), float(point.y), float(point.z))
        stem = str(rally.score_label or f'rally_{rally.rally_index}')
        if '/' in stem or '\\' in stem or '..' in stem:
            stem = f'rally_{rally.rally_index}'
        if 'ball' in selected:
            archive.writestr(f'ball/{stem}.npy', _npy(ball))
            count += 1
        if 'ball-mask' in selected:
            archive.writestr(f'ball-mask/{stem}.npy', _npy(mask))
            count += 1
    return count


def _export_2d(archive, db, match_id):
    response = export_corrected_ball_2d(match_id, match_number=None, db=db)
    count = 0
    with zipfile.ZipFile(io.BytesIO(response.body)) as source:
        for item in source.infolist():
            if item.is_dir():
                continue
            archive.writestr('ball-2d/' + item.filename, source.read(item))
            count += 1
    return count


def _export_reconstruction(archive, match_id):
    manifest = read_match_asset_manifest(match_id) or {}
    root = match_asset_dir(match_id).resolve()
    count = 0
    written = set()
    for rally in (manifest.get('rallies') or {}).values():
        score = str(rally.get('score', ''))
        for player, item in (rally.get('players') or {}).items():
            relpath = str(item.get('path', ''))
            file = (root / relpath).resolve()
            if not file.is_relative_to(root) or not file.is_file():
                continue
            name = f'human-racket/new_racket/{score}_{player}.npz'
            if name not in written:
                archive.write(file, name)
                written.add(name)
                count += 1
    reconstruction = manifest.get('reconstruction') or {}
    archive.writestr('human-racket/reconstruction_info.json',
                     json.dumps(reconstruction, ensure_ascii=False, indent=2))
    return count + 1


@router.get('/matches/{match_id}/dataset-export')
def export_dataset_categories(
    match_id: int,
    background_tasks: BackgroundTasks,
    categories: str = Query(..., min_length=1),
    db: Session = Depends(get_db),
):
    """類別與新增資料集畫面一致；ZIP 中附帶重建資料的來源說明。"""
    selected = [part.strip() for part in categories.split(',')]
    if not selected or any(part not in CATEGORY_NAMES for part in selected) or len(set(selected)) != len(selected):
        raise HTTPException(400, detail='匯出類別無效或重複')
    match = db.get(Match, match_id)
    if match is None:
        raise HTTPException(404, detail='找不到資料集')
    rallies = db.query(Rally).filter(Rally.match_id == match_id).order_by(Rally.start_frame).all()
    file = tempfile.NamedTemporaryFile(prefix='badminton_export_', suffix='.zip', delete=False)
    filename = file.name
    file.close()
    try:
        counts = {}
        with zipfile.ZipFile(filename, 'w', zipfile.ZIP_DEFLATED, compresslevel=5) as archive:
            if 'cameras' in selected:
                counts['cameras'] = _export_cameras(archive, match)
            if 'rally-data' in selected:
                counts['rally-data'] = _export_rallies(archive, db, match_id, rallies)
            if 'ball' in selected or 'ball-mask' in selected:
                _export_ball_arrays(archive, db, match_id, rallies, selected)
                if 'ball' in selected:
                    counts['ball'] = len([name for name in archive.namelist() if name.startswith('ball/')])
                if 'ball-mask' in selected:
                    counts['ball-mask'] = len([name for name in archive.namelist() if name.startswith('ball-mask/')])
            if 'ball-2d' in selected:
                counts['ball-2d'] = _export_2d(archive, db, match_id)
            if 'human-racket' in selected:
                counts['human-racket'] = _export_reconstruction(archive, match_id)
            archive.writestr('export_info.json', json.dumps({
                'match_id': match_id,
                'selected_categories': selected,
                'file_counts': counts,
                'notes': [
                    'ball 與 ball-mask 是根據資料庫有效 3D 點重建，原始 mask=0 時的座標無法恢復。',
                    'human-racket 是匯入時轉換的 NPZ，並非原始 PTH。',
                    'rally-data 由資料庫資料重建；原始 CSV 額外欄位不保證保留。',
                    'ball-2d 是原始 2D 加上修正層的結果；原始資料庫不會被修改。',
                ],
            }, ensure_ascii=False, indent=2))
    except Exception:
        Path(filename).unlink(missing_ok=True)
        raise
    background_tasks.add_task(Path(filename).unlink, missing_ok=True)
    return FileResponse(filename, media_type='application/zip',
                        filename=f'badminton_dataset_{match_id}_selected.zip',
                        background=background_tasks)
